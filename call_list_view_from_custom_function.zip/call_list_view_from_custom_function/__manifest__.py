# -*- coding: utf-8 -*-
{
    'name' : 'Call List view from custom function',
    'version': '1.0',
    'author': 'Rishan Malaka',
    'category': 'Product',
    'description':
        """
This module allow to call list view from custom function 

==========================

        """,
    'data': [
        "views/list_product_view.xml",
    ],
    'depends': [
        "base",
        "sale",
        "product"
    ],
    'license': "LGPL-3",
    'installable': True,
    'auto_install': False,
    'application': False,
}
