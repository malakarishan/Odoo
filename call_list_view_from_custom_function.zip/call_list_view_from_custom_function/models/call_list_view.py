# -*- coding: utf-8 -*-

from odoo import models, fields, api, tools, _


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    # get duplicate sku list
    @api.multi
    def call_list_view(self):
        product_list = []
        for data in self.order_line:
            product_id = data.product_id.id
            product_list.append(product_id)
        view_id = self.env.ref('call_list_view_from_custom_function.tree_duplicate_products').id
        return {
            'name': 'Product View',
            'view_mode': 'tree',
            'views': [[view_id, 'tree']],
            'res_model': 'product.template',
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', product_list)],
            'target': 'current',
        }
